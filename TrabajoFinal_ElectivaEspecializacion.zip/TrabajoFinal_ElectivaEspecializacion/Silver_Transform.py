from pyspark.sql import SparkSession, functions as F
spark = SparkSession.builder.getOrCreate()

CATALOG = "trabajofinal"
BRONZE = f"{CATALOG}.bronze"
SILVER = f"{CATALOG}.silver"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {SILVER}")

flights = spark.table(f"{BRONZE}.flights")
airlines = spark.table(f"{BRONZE}.airlines").select("airline_id", "airline_name")
airports = spark.table(f"{BRONZE}.airports")

origin = airports.select(
    F.col("airport_id").alias("origin_airport"),
    F.col("city").alias("origin_city"), F.col("country").alias("origin_country"))
destination = airports.select(
    F.col("airport_id").alias("destination_airport"),
    F.col("city").alias("destination_city"), F.col("country").alias("destination_country"))

silver = (flights.join(airlines, "airline_id", "left")
    .join(origin, "origin_airport", "left")
    .join(destination, "destination_airport", "left")
    .withColumn("delay_total",
        F.when(F.col("departure_delay").isNotNull() & F.col("arrival_delay").isNotNull(),
               F.col("departure_delay") + F.col("arrival_delay")))
    .withColumn("on_time",
        F.when(F.col("arrival_delay").isNull(), F.lit(None).cast("boolean"))
         .otherwise(F.col("arrival_delay") <= 15))
    .withColumn("distance_km", F.round(F.col("distance_miles") * 1.609344, 2))
    .withColumn("delay_category",
        F.when(F.col("delay_total").isNull(), F.lit(None).cast("string"))
         .when(F.col("delay_total") <= 0, "None")
         .when(F.col("delay_total") <= 15, "Short")
         .when(F.col("delay_total") <= 60, "Medium").otherwise("Long"))
    .fillna("Unknown", subset=[
        "airline_name", "origin_city", "origin_country",
        "destination_city", "destination_country"]))

airline_metrics = (silver.groupBy("airline_id", "airline_name").agg(
    F.count("*").alias("total_flights"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
    F.round(F.sum("distance_km"), 2).alias("total_distance_km"),
    F.count("on_time").alias("flights_with_known_punctuality"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2)
     .alias("on_time_percentage")))

airline_origin_metrics = (silver.groupBy(
    "airline_id", "airline_name", "origin_airport", "origin_city", "origin_country"
).agg(
    F.count("*").alias("total_flights"),
    F.count("on_time").alias("flights_with_known_punctuality"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2)
     .alias("on_time_percentage")))

departures = (silver.groupBy("origin_airport", "origin_city", "origin_country").agg(
    F.count("*").alias("outgoing_flights"),
    F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"))
    .select(F.col("origin_airport").alias("airport_id"),
            F.col("origin_city").alias("dep_city"),
            F.col("origin_country").alias("dep_country"),
            "outgoing_flights", "avg_departure_delay"))

arrivals = (silver.groupBy("destination_airport", "destination_city", "destination_country").agg(
    F.count("*").alias("incoming_flights"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
    F.count("on_time").alias("arrivals_with_known_punctuality"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2)
     .alias("on_time_percentage"))
    .select(F.col("destination_airport").alias("airport_id"),
            F.col("destination_city").alias("arr_city"),
            F.col("destination_country").alias("arr_country"),
            "incoming_flights", "avg_arrival_delay",
            "arrivals_with_known_punctuality", "on_time_percentage"))

airport_metrics = (departures.alias("d").join(arrivals.alias("a"), "airport_id", "full_outer")
    .select("airport_id",
        F.coalesce("dep_city", "arr_city", F.lit("Unknown")).alias("city"),
        F.coalesce("dep_country", "arr_country", F.lit("Unknown")).alias("country"),
        F.coalesce("outgoing_flights", F.lit(0)).alias("outgoing_flights"),
        F.coalesce("incoming_flights", F.lit(0)).alias("incoming_flights"),
        "avg_departure_delay", "avg_arrival_delay",
        F.coalesce("arrivals_with_known_punctuality", F.lit(0)).alias("arrivals_with_known_punctuality"),
        "on_time_percentage"))

for name, data in [
    ("flights_enriched", silver),
    ("airline_metrics", airline_metrics),
    ("airport_metrics", airport_metrics),
    ("airline_origin_metrics", airline_origin_metrics)
]:
    (data.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .saveAsTable(f"{SILVER}.{name}"))
    print(f"Silver table updated: {SILVER}.{name}")

print("Silver_Transform completed.")
