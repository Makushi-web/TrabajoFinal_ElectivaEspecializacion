from pyspark.sql import SparkSession, functions as F
spark = SparkSession.builder.getOrCreate()

CATALOG = "trabajofinal"
LANDING = f"/Volumes/{CATALOG}/data/landing"
BRONZE = f"{CATALOG}.bronze"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {BRONZE}")

def read_csv(name):
    return (spark.read.format("csv").option("header", True)
            .option("inferSchema", False).option("mode", "PERMISSIVE")
            .load(f"{LANDING}/{name}"))

flights = read_csv("flights.csv")
airlines = read_csv("airlines.csv")
airports = read_csv("airports.csv")

flights = (flights
    .withColumn("flight_id", F.trim("flight_id"))
    .withColumn("flight_date", F.to_date("flight_date", "yyyy-MM-dd"))
    .withColumn("airline_id", F.trim("airline_id"))
    .withColumn("origin_airport", F.trim("origin_airport"))
    .withColumn("destination_airport", F.trim("destination_airport"))
    .withColumn("departure_delay", F.col("departure_delay").cast("double").cast("int"))
    .withColumn("arrival_delay", F.col("arrival_delay").cast("double").cast("int"))
    .withColumn("distance_miles", F.col("distance_miles").cast("int"))
    .dropna(subset=["flight_id", "airline_id", "origin_airport"])
    .withColumn("ingest_timestamp", F.current_timestamp()))

airlines = (airlines.withColumn("airline_id", F.trim("airline_id"))
    .withColumn("airline_name", F.trim("airline_name"))
    .dropna(subset=["airline_id"])
    .withColumn("ingest_timestamp", F.current_timestamp()))

airports = (airports.withColumn("airport_id", F.trim("airport_id"))
    .withColumn("city", F.trim("city"))
    .withColumn("country", F.trim("country"))
    .dropna(subset=["airport_id"])
    .withColumn("ingest_timestamp", F.current_timestamp()))

for name, data in [("flights", flights), ("airlines", airlines), ("airports", airports)]:
    (data.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .saveAsTable(f"{BRONZE}.{name}"))
    print(f"Bronze table updated: {BRONZE}.{name}")

print("Bronze_Ingestion completed.")
