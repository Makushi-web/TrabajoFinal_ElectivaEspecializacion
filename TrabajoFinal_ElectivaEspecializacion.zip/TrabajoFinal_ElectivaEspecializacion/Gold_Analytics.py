from pyspark.sql import SparkSession, functions as F
from pyspark.sql.window import Window
spark = SparkSession.builder.getOrCreate()

CATALOG = "trabajofinal"
SILVER = f"{CATALOG}.silver"
GOLD = f"{CATALOG}.gold"
spark.sql(f"CREATE SCHEMA IF NOT EXISTS {GOLD}")
df = spark.table(f"{SILVER}.flights_enriched")

temporal = (df.withColumn("year", F.year("flight_date"))
    .withColumn("month", F.month("flight_date"))
    .withColumn("month_name", F.date_format("flight_date", "MMMM"))
    .withColumn("day_of_week", F.dayofweek("flight_date"))
    .withColumn("day_name", F.date_format("flight_date", "EEEE"))
    .withColumn("quarter", F.quarter("flight_date")))

delay_month = temporal.groupBy("year", "month", "month_name").agg(
    F.count("*").alias("total_flights"), F.round(F.avg("arrival_delay"), 2).alias("avg_delay"))
delay_weekday = temporal.groupBy("day_of_week", "day_name").agg(
    F.count("*").alias("total_flights"), F.round(F.avg("arrival_delay"), 2).alias("avg_delay"))
delay_quarter = temporal.groupBy("year", "quarter").agg(
    F.count("*").alias("total_flights"), F.round(F.avg("arrival_delay"), 2).alias("avg_delay"))

win_row = Window.partitionBy("airline_id").orderBy(F.col("delay_total").desc(), F.col("flight_id"))
win_dense = Window.partitionBy("airline_id").orderBy(F.col("delay_total").desc())
top_row = (df.filter(F.col("delay_total").isNotNull())
    .withColumn("flight_rank", F.row_number().over(win_row)).filter("flight_rank <= 5"))
top_dense = (df.filter(F.col("delay_total").isNotNull())
    .withColumn("flight_rank", F.dense_rank().over(win_dense)).filter("flight_rank <= 5"))

airport_delay = (df.groupBy("origin_airport", "origin_city", "origin_country").agg(
    F.count("*").alias("total_outgoing_flights"),
    F.round(F.avg("departure_delay"), 2).alias("avg_delay"))
    .filter(F.col("avg_delay").isNotNull())
    .withColumn("airport_rank", F.dense_rank().over(Window.orderBy(F.col("avg_delay").desc()))))

airline_month = temporal.groupBy(
    "airline_id", "airline_name", "year", "month", "month_name").agg(
    F.count("*").alias("total_flights"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
    F.count("on_time").alias("flights_with_known_punctuality"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2)
     .alias("on_time_percentage"))

business_monthly = temporal.groupBy(
    "airline_id", "airline_name", "origin_airport", "origin_city", "origin_country", "year", "month"
).agg(
    F.count("*").alias("total_flights"),
    F.round(F.avg("departure_delay"), 2).alias("avg_departure_delay"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
    F.round(F.avg("delay_total"), 2).alias("avg_total_delay"))

airport_punctuality = (df.groupBy(
    F.col("destination_airport").alias("airport_id"),
    F.col("destination_city").alias("city"),
    F.col("destination_country").alias("country")).agg(
    F.count("*").alias("total_flights"),
    F.count("on_time").alias("flights_with_known_punctuality"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2).alias("on_time_percentage"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"))
    .filter(F.col("flights_with_known_punctuality") > 0)
    .withColumn("punctuality_rank", F.dense_rank().over(
        Window.orderBy(F.col("on_time_percentage").desc()))))

airline_kpi = df.groupBy("airline_id", "airline_name").agg(
    F.count("*").alias("total_flights"),
    F.sum(F.when(F.col("on_time") == True, 1).otherwise(0)).alias("on_time_flights"),
    F.sum(F.when(F.col("on_time") == False, 1).otherwise(0)).alias("delayed_flights"),
    F.count("on_time").alias("flights_with_known_punctuality"),
    F.round(F.avg("arrival_delay"), 2).alias("avg_arrival_delay"),
    F.round(F.avg(F.when(F.col("on_time") == True, 1.0)
                   .when(F.col("on_time") == False, 0.0)) * 100, 2)
     .alias("on_time_percentage"))

tables = {
    "delay_by_month": delay_month,
    "delay_by_weekday": delay_weekday,
    "delay_by_quarter": delay_quarter,
    "top_flights_row_number": top_row,
    "top_flights_dense_rank": top_dense,
    "airport_delay_ranking": airport_delay,
    "airline_month_metrics": airline_month,
    "business_monthly_delay": business_monthly,
    "airport_punctuality_ranking": airport_punctuality,
    "airline_punctuality_kpi": airline_kpi,
}

for name, data in tables.items():
    (data.write.format("delta").mode("overwrite").option("overwriteSchema", "true")
     .saveAsTable(f"{GOLD}.{name}"))
    print(f"Gold table updated: {GOLD}.{name}")

# OPTIMIZE/ZORDER is attempted on the larger business tables; unsupported configurations
# are reported without preventing the analytics tables from being written.
for name, zorder in [
    ("business_monthly_delay", "year, month, airline_id, origin_airport"),
    ("airport_punctuality_ranking", "airport_id"),
    ("airline_punctuality_kpi", "airline_id")
]:
    try:
        spark.sql(f"OPTIMIZE {GOLD}.{name} ZORDER BY ({zorder})")
    except Exception as e:
        print(f"OPTIMIZE skipped for {name}: {e}")

for name in tables:
    try:
        spark.sql(f"ANALYZE TABLE {GOLD}.{name} COMPUTE STATISTICS")
    except Exception as e:
        print(f"ANALYZE skipped for {name}: {e}")

print("Gold_Analytics completed.")
